@extends('layouts.parent')
@section('content')
{{-- @dd($branch) --}}
<div class="col-12 grid-margin stretch-card">
    <div class="card">
      <div class="card-body">
        <h4 class="card-title pb-5">Reports</h4>
        <form method="post" action="{{url('/admin/reports/export')}}">
                  @csrf
                  <div class="form-group">
                    <label class="form-control-label">From</label>
                    <input type="date" name="from" class="form-control">                  
                  </div>
                  <div class="form-group">
                    <label class="form-control-label">To</label>
                    <input type="date" name="to" class="form-control">                  
                  </div>
                  <button type="submit" class="btn btn-info request-plan">Generate Reports</button>
  </form>
      </div>
    </div>
  </div>
@endsection
