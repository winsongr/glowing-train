@extends('layouts.parent')
@section('content')
{{-- @dd($branch) --}}
<div class="col-12 grid-margin stretch-card">
   <div class="card">
      <div class="card-body">
        @if (session('message'))
                          <div class="alert alert-success mt-5">
                              {{ session('message') }}
                          </div>
                        @endif
         @if(!empty($userData))
         <h4 class="card-title pb-5">Update User</h4>
         <form method="post" action="/admin/{{Crypt::encrypt($userData->id)}}/users">
            @method('put')
            @else
            <h4 class="card-title pb-5">Create User</h4>
         <form method="post" action="/admin/users">
            @endif 
            @csrf
            <div class="form-group">
               <label for="name">Name</label>
               <input type="text" class="form-control @error('name') is-invalid @enderror" name="name" value="{{ empty($userData->name) ? '':$userData->name }}">
               @error('name')
               <div class="text-danger">{{ $message }}</div>
               @enderror
            </div>
            <div class="form-group">
               <label for="phone">Phone</label>
               <input  type="text" class="form-control @error('phone') is-invalid @enderror" name="phone" required value="{{ empty($userData->phone) ? '':$userData->phone }}">
               @error('phone')
               <span class="invalid-feedback" role="alert">
               <strong>{{ $message }}</strong>
               </span>
               @enderror
            </div>
            <div class="form-group ">
               <label for="email">Email</label>
               <input  type="email" class="form-control @error('email') is-invalid @enderror" name="email" value="{{ empty($userData->user->email) ? '':$userData->user->email }}"  required autocomplete="email">
               @error('email')
               <span class="invalid-feedback" role="alert">
               <strong>{{ $message }}</strong>
               </span>
               @enderror
            </div>
            <div class="form-group">
               <label for="branch">Branch</label>
               <select class="form-control @error('branch') is-invalid @enderror" name="branch">
                  <option value="">Select Branch</option>
                  @foreach($branch as $value)
                  @if(!empty($userData))
                  <option value="{{Crypt::encrypt($value->id)}}" {{$userData->branch_id==$value->id ? 'selected' : ""}}>{{$value->name}}</option>
                  @else
                  <option value="{{Crypt::encrypt($value->id)}}">{{$value->name}}</option>
                  @endif
                  @endforeach
               </select>
               @error('branch')
               <span class="invalid-feedback" role="alert">
               <strong>{{ $message }}</strong>
               </span>
               @enderror
            </div>
            <div class="form-group">
               <label for="password">Password</label>
               <input  type="password" class="form-control @error('password') is-invalid @enderror" name="password" required  autocomplete="new-password" value="{{ empty($userData->user->password) ? '':$userData->user->password }}">
            <input type="hidden" name="old-password" value="{{ empty($userData->user->password) ? '':$userData->user->password }}">

               @error('password')
               <span class="invalid-feedback" role="alert">
               <strong>{{ $message }}</strong>
               </span>
               @enderror
            </div>
            <button type="submit" class="btn btn-gradient-info mr-2">{{!empty($userData)?'Update' : 'Save' }}</button>
            <a href="/admin/users" class="btn btn-light">Back</a>
         </form>
      </div>
   </div>
</div>
@endsection