@extends('layouts.parent')
@section('content')
{{-- @dd($users) --}}
<div class="col-lg-12 grid-margin stretch-card">
                <div class="card">
                  <div class="card-body">
                    <div class="mb-5">
                        @if (session('status'))
                          <div class="alert alert-success mt-5">
                              {{ session('status') }}
                          </div>
                        @endif
                      <div class="float-right pb-3">
                            <a href="/admin/users/create" class="btn btn-gradient-info pull-right">Create User</a>
                      </div>
                        <h4 class="users card-title">Users</h4>
                    </div>
                    <div class="table-responsive py-4">

                    <table class="table datatable">
                      <thead>
                        <tr>
                          <th>S.No</th>
                          <th>Name</th>
                          <th>Phone</th>
                          <th>Action</th>
                        </tr>
                      </thead>
                      <tbody>
                        @foreach($users as $key => $value)
                        <tr>
                          <td>{{$key+1}}</td>
                          <td>{{$value->name}}</td>
                          <td >{{$value->phone}}</td>
                          <td>
                            @if($value->user->status=='1')
                            <button type="button" class="btn btn-gradient-danger" onclick="userAction('suspend','put','{{Crypt::encrypt($value->user->id)}}')">Suspend</button>
                            @else
                            <button type="button" class="btn btn-gradient-success" onclick="userAction('activate','put','{{Crypt::encrypt($value->user->id)}}')">Activate</button>
                            @endif
                            <a href="/admin/{{Crypt::encrypt($value->id)}}/user" class="btn btn-gradient-info mr-2">View</button>
                            <a href="/admin/{{Crypt::encrypt($value->id)}}/users" class="btn btn-gradient-primary">Edit</button>
                          
                        </tr>
                        @endforeach
                        
                      </tbody>
                    </table>
                  </div>
                  </div>
                </div>
              </div>
      @endsection
    