@extends('layouts.parent')
@section('content')

admin
@endsection
